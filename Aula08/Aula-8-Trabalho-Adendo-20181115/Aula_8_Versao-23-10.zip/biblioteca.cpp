#include<stdio.h>
#include<conio.h>
#include<string.h>

int main() {
    FILE *fd;
    
    //////////////////////////////
    struct livro {
        char isbn[14];
        char titulo[50];
        char autor[50];
        char ano[5];
    } vet[5] = {{"3333333333333", "TiT-3", "Autor-A-1.3", "3333"},
                {"2222222222222", "TiT-2", "Autor-B", "2222"},                
                {"1111111111111", "TiT-1", "Autor-A-1.3", "1111"},                
                {"6666666666666", "Titulo-6", "Autor-A-1.3", "6666"},                
                {"5555555555555", "T-5", "Autor-B", "5555"},
                
                };
       
    fd = fopen("biblioteca.bin", "w+b");
    fwrite(vet, sizeof(vet), 1, fd);
    fclose(fd);
    
    //////////////////////////////
	struct busca {
        char isbn[14];
    } vet_b[3] = {{"3333333333333"},
                  {"2222222222222"},
                  {"7777777777777"}};
       
    fd = fopen("busca.bin", "w+b");
    fwrite(vet_b, sizeof(vet_b), 1, fd);
    fclose(fd);
    
    //////////////////////////////
	struct consulta_casada {
        char isbn1[14];
        char isbn2[14];
    } vet_cc[2];
    
    //%%%%%
    strcpy(vet_cc[0].isbn1,"3333333333333");
    strcpy(vet_cc[0].isbn2,"6666666666666");
    
    strcpy(vet_cc[1].isbn1,"7777777777777");
    strcpy(vet_cc[1].isbn2,"2222222222222");
    
    //%%%%%   
    fd = fopen("consulta_casada.bin", "w+b");
    fwrite(vet_cc, sizeof(vet_cc), 1, fd);
    fclose(fd);
    
    //////////////////////////////
    struct remove {
        char isbn[14];
    } vet_r[3] = {{"6666666666666"},
                  {"3333333333333"},
                  {"7777777777777"}};
       
    fd = fopen("remove.bin", "w+b");
    fwrite(vet_r, sizeof(vet_r), 1, fd);
    fclose(fd);
}
